// Author:
// Net ID:
// Date:
// Assignment:     Lab 3
//
// Description: This file contains a programmatic overall description of the
// program. It should never contain assignments to special function registers
// for the exception key one-line code such as checking the state of the pin.
//
// Requirements:
//----------------------------------------------------------------------//




#include <arduino.h>
#include <avr/io.h>
#include "led.h"
#include "switch.h"
#include "timer.h"
#include "lcd.h"

// defines


/*
 * Define a set of states that can be used in the state machine using an enum.
 */
typedef enum button_states {
  wait_press, debounce_press, wait_release, debounce_release
} stateType;
stateType state = wait_press;

int currDelay = 100; // Delay time in ms


// Initialize states.  Remember to use volatile 




int main(){

  initTimer1();
  initTimer0();
  initLCD();
  initSwitchPB3();
  initLED();
  moveCursor(0, 0); // moves the cursor to 0,0 position
  writeString("Current mode: ");
  moveCursor(1, 0);  // moves the cursor to 1,0 position
  writeString("Fast");
  moveCursor(1, 5);
  unsigned char ArrayCh[]={0x00, 0x04, 0x0c, 0x0c, 0x1e, 0x06, 0x0c, 0x08};
  writeCharacter(0x00);
  setCGRAM(0X40);
  unsigned int i=0;
  while(i<=7){
    writeCharacter(ArrayCh[i]);
    i++;
  }
  sei(); // Enable global interrupts.

  int num = 0;
  /*
  * Implement a state machine in the while loop which achieves the assignment
  * requirements.
  */
	while (1) {
    //Cycle through numbers 0-15
    if (num >= 16) {
      num = 0;
    }
    turnOnLEDWithChar(num);
    num++;

    delayMs(currDelay); //Delay based on current delay value

    //Switch between button states
    switch(state){
      case wait_press:
        break;
      case debounce_press:
        delayMs(1);
        state = wait_release;
        break;
      case wait_release:
        break;
      case debounce_release:
        delayMs(1);
        state = wait_press;
        break;
    }
	}

// while loop
  
  return 0;
}

/* Implement an Pin Change Interrupt which handles the switch being
* pressed and released. When the switch is pressed and released, the LEDs
* change at twice the original rate. If the LEDs are already changing at twice
* the original rate, it goes back to the original rate.
*/
ISR(PCINT0_vect){
  if(state == wait_press){
    state = debounce_press;
  }
  else if (state == wait_release){
    //Change delay value
    if (currDelay == 100) {
      currDelay = 200;
      moveCursor(1, 0);  // moves the cursor to 1,0 position
      writeString("Slow");
      moveCursor(1, 5);
      unsigned char ArrayCh[]={0x00, 0x00, 0x00, 0x14, 0x0e, 0x0a, 0x00, 0x00};
      writeCharacter(0x00);
      setCGRAM(0X40);
      unsigned int i=0;
      while(i<=7){
        writeCharacter(ArrayCh[i]);
        i++;
      }
    } else {
      currDelay = 100;
      moveCursor(1, 0);  // moves the cursor to 1,0 position
      writeString("Fast");
      moveCursor(1, 5);
      unsigned char ArrayCh[]={0x00, 0x04, 0x0c, 0x0c, 0x1e, 0x06, 0x0c, 0x08};
      writeCharacter(0x00);
      setCGRAM(0X40);
      unsigned int i=0;
      while(i<=7){
        writeCharacter(ArrayCh[i]);
        i++;
      }
    }
    state = debounce_release;
  }
}