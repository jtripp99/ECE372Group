// Author: 
// Net ID: 
// Date: 
// Assignment: Lab 3
//----------------------------------------------------------------------//

#include "timer.h"
//You many use any timer you wish for the microsecond delay and the millisecond delay


/* Initialize timer 1, you should not turn the timer on here. Use CTC mode  .*/
void initTimer1(){
	//To set into CTC mode, we need WGM13 to be 0, WGM12 to be 1, WGM11 to 0, WGM10 to be 0
    TCCR1A &= ~((1 << WGM11) | (1 << WGM10));
    TCCR1B |= (1 << WGM12);
    TCCR1B &= ~(1 << WGM13);
}

/* This delays the program an amount of microseconds specified by unsigned int delay.
*/
void delayUs(unsigned int delay){
unsigned int count = 0;

    //want a time delay of 1 us, so count = (Time delay * frequency of clock)/Prescalar
    //16 = (1us * 16MHz)/1

    //Need to interface a 16 bit module, which means writing the high byte first, then the low byte
    //16 in hex is 00 10
    OCR1A = 16;
    

    //Turn on timer with default clock source, no prescaler delay
    TCCR1B &= ~((1 << CS12) | (1 << CS11));
    TCCR1B |= (1 << CS10); //by setting CS12 CS11 CS10 to 001, turn on clock

    while(count < delay){ //while count is less than delay
        
        //Sets the timer flag to 1
        TIFR1 |= (1 << OCF1A); //logic 1 is flag down
        
        //Set the timer register to 0
        TCNT1 = 0;

        //while flag is down do not do anything
        while(!(TIFR1 & (1 << OCF1A))); //!number is equivalent to number != 0
        //when while loop breaks, (0 & 1) = 0, which IS equal to 0.

        count++; //1 microsecond delay as been achieved, go to next microsecond
    }

    //turn timer off
    TCCR1B &= ~((1 << CS12) | (1 << CS11) | (1 << CS10));
}

/* Initialize timer 0, you should not turn the timer on here.
* You will need to use CTC mode */
void initTimer0(){
    // 1.choose CTC Mode
    TCCR0A&=~(1<<WGM00);
    TCCR0A|=(1<<WGM01); // CTC MODE 010 WGM2=0, WGM1=1, WGM0=0
    TCCR0B&=~(1<<WGM02);
    /// 2. Choose prescaller=64  011
    TCCR0B|=(1<<CS00);
    TCCR0B|=(1<<CS01);
    TCCR0B&=~(1<<CS02);

    //3. Counting Reg
    TCNT0=0;
    //4. Compare Value
    OCR0A=249;
}

/* This delays the program an amount specified by unsigned int delay.
* Use timer 0. Keep in mind that you need to choose your prescalar wisely
* such that your timer is precise to 1 millisecond and can be used for
* 100-2000 milliseconds
*/
void delayMs(unsigned int delay){
    TCNT0=0;
    int counter=0;
    TIFR0|=(1<<OCF0A);// Reset the flag to 0
    while(counter<delay){
        while(!(TIFR0&(1<<OCF0A)));
        /// OR instead of while use--> if((TIFR0&(1<<OCF0A))){
            counter++;
                TIFR0|=(1<<OCF0A);// Reset the flag to 0
        // } //end for if 

    }
}